<?php

namespace Drupal\Component\Plugin\Exception;

/**
 * Exception interface for all exceptions thrown by the Plugin component.
 */
interface ExceptionInterface {}
